export const environment = {
    firebaseConfig: {
        apiKey: "AIzaSyBErKVTY-hI3e8VsJ8xwCokc4jj62WBxz4",
        authDomain: "webker.firebaseapp.com",
        projectId: "webker",
        storageBucket: "webker.appspot.com",
        messagingSenderId: "724729778437",
        appId: "1:724729778437:web:91c35de14662b7aed5a76c"
    }
};

